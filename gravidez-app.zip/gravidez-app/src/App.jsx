import { useState, useEffect } from "react";

const STORAGE_KEY = "gravidez-app-v1";

const DESENVOLVIMENTO = {
  13: { tamanho: "Limão", cm: "7,4 cm", peso: "23 g", desc: "O bebê já tem impressões digitais! Os órgãos internos estão formados e ele começa a produzir urina.", emoji: "🍋" },
  14: { tamanho: "Pêssego", cm: "8,7 cm", peso: "43 g", desc: "O bebê já consegue fazer caretas e sugar o polegar. O corpo cresce mais rápido que a cabeça agora.", emoji: "🍑" },
  15: { tamanho: "Maçã", cm: "10,1 cm", peso: "70 g", desc: "Os ossos estão endurecendo e as pernas já são maiores que os braços. Pode começar a sentir movimentos!", emoji: "🍎" },
  16: { tamanho: "Abacate", cm: "11,6 cm", peso: "100 g", desc: "O bebê já ouve sua voz! O coração bombeia cerca de 25 litros de sangue por dia.", emoji: "🥑" },
  17: { tamanho: "Pera", cm: "13 cm", peso: "140 g", desc: "Uma camada de gordura começa a se formar sob a pele. O cordão umbilical fica mais grosso e resistente.", emoji: "🍐" },
  18: { tamanho: "Pimentão", cm: "14,2 cm", peso: "190 g", desc: "Hora do ultrassom morfológico! Dá para ver o sexo do bebê. Ele já tem padrão de sono e vigília.", emoji: "🫑" },
  19: { tamanho: "Manga", cm: "15,3 cm", peso: "240 g", desc: "Os sentidos estão se desenvolvendo rapidamente. O vernix caseoso (camada branca protetora) cobre a pele.", emoji: "🥭" },
  20: { tamanho: "Banana", cm: "16,4 cm", peso: "300 g", desc: "Metade da gestação! O bebê engole líquido amniótico e pratica a digestão. Os movimentos são mais fortes.", emoji: "🍌" },
  21: { tamanho: "Cenoura", cm: "26,7 cm", peso: "360 g", desc: "O bebê já tem sobrancelhas e cílios. Ele dorme bastante, cerca de 12 a 14 horas por dia.", emoji: "🥕" },
  22: { tamanho: "Milho", cm: "27,8 cm", peso: "430 g", desc: "O sentido do tato está bem desenvolvido. O bebê explora seu próprio rosto e o cordão umbilical.", emoji: "🌽" },
  23: { tamanho: "Toranja", cm: "28,9 cm", peso: "500 g", desc: "Os pulmões estão se preparando para respirar. O bebê já reage a sons altos com movimentos.", emoji: "🍊" },
  24: { tamanho: "Espiga de Milho", cm: "30 cm", peso: "600 g", desc: "Marco importante! O bebê teria chances de sobreviver fora do útero com cuidados intensivos.", emoji: "🌾" },
  25: { tamanho: "Couve-flor", cm: "34,6 cm", peso: "660 g", desc: "O cabelo começa a crescer com cor e textura. A gordura corporal continua aumentando.", emoji: "🥦" },
  26: { tamanho: "Alface", cm: "35,6 cm", peso: "760 g", desc: "Os olhos começam a se abrir! O bebê já responde à luz. Os pulmões produzem surfactante.", emoji: "🥬" },
  27: { tamanho: "Repolho", cm: "36,6 cm", peso: "875 g", desc: "Último trimestre chegando! O cérebro está em desenvolvimento intenso. O bebê pode ter soluços.", emoji: "🥗" },
};

const SINTOMAS_OPCOES = [
  "Náusea", "Enjoo", "Cansaço", "Dor nas costas", "Inchaço nos pés",
  "Azia", "Insônia", "Dores de cabeça", "Movimentos do bebê", "Humor ótimo",
  "Ansiedade", "Fome constante", "Vontades específicas", "Dor pélvica", "Bem-disposta",
];

const HUMOR_CONFIG = [
  { valor: 5, emoji: "😄", label: "Ótima" },
  { valor: 4, emoji: "🙂", label: "Bem" },
  { valor: 3, emoji: "😐", label: "Ok" },
  { valor: 2, emoji: "😔", label: "Cansada" },
  { valor: 1, emoji: "😢", label: "Difícil" },
];

const ABAS = [
  { key: "inicio", label: "🏠 Início" },
  { key: "desenvolvimento", label: "👶 Bebê" },
  { key: "consultas", label: "🏥 Consultas" },
  { key: "diario", label: "📔 Diário" },
];

function semanaAtual(dataInicio) {
  if (!dataInicio) return 20;
  const diff = Date.now() - new Date(dataInicio).getTime();
  const semanas = Math.floor(diff / (7 * 24 * 60 * 60 * 1000));
  return Math.min(Math.max(semanas, 1), 40);
}

function formatData(iso) {
  if (!iso) return "—";
  const [y, m, d] = iso.split("-");
  return `${d}/${m}/${y}`;
}

export default function App() {
  const [aba, setAba] = useState("inicio");
  const [state, setState] = useState({
    nomeBebe: "", nomesMae: "", nomesPai: "",
    dataInicio: "", // data da última menstruação ou DUM
    semanaManual: 20,
    usarSemanaManual: true,
    consultas: [],
    entradas: [], // diário
    toast: null,
  });
  const [novaConsulta, setNovaConsulta] = useState({ data: "", tipo: "", medico: "", local: "", obs: "", lembrete: false });
  const [novaEntrada, setNovaEntrada] = useState({ humor: 3, sintomas: [], texto: "", peso: "", barriga: "" });
  const [showConsultaForm, setShowConsultaForm] = useState(false);
  const [showEntradaForm, setShowEntradaForm] = useState(false);
  const [showConfig, setShowConfig] = useState(false);
  const [config, setConfig] = useState({ nomeBebe: "", nomeMae: "Mamãe", nomePai: "Papai", semana: 20 });

  useEffect(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY);
      if (saved) {
        const parsed = JSON.parse(saved);
        setState(s => ({ ...s, ...parsed }));
        setConfig(c => ({ ...c, nomeBebe: parsed.nomeBebe || "", nomeMae: parsed.nomeMae || "Mamãe", nomePai: parsed.nomePai || "Papai", semana: parsed.semanaManual || 20 }));
      } else {
        setShowConfig(true);
      }
    } catch {}
  }, []);

  function save(updates) {
    const next = { ...state, ...updates };
    setState(next);
    try { localStorage.setItem(STORAGE_KEY, JSON.stringify(next)); } catch {}
  }

  function showToast(msg, type = "success") {
    setState(s => ({ ...s, toast: { msg, type } }));
    setTimeout(() => setState(s => ({ ...s, toast: null })), 2500);
  }

  function salvarConfig() {
    save({ nomeBebe: config.nomeBebe, nomeMae: config.nomeMae, nomePai: config.nomePai, semanaManual: config.semana });
    setShowConfig(false);
    showToast("Configurações salvas! 💕");
  }

  function adicionarConsulta() {
    if (!novaConsulta.data || !novaConsulta.tipo) { showToast("Preencha data e tipo.", "error"); return; }
    const updated = [{ ...novaConsulta, id: Date.now() }, ...state.consultas]
      .sort((a, b) => new Date(a.data) - new Date(b.data));
    save({ consultas: updated });
    setNovaConsulta({ data: "", tipo: "", medico: "", local: "", obs: "", lembrete: false });
    setShowConsultaForm(false);
    showToast("Consulta adicionada! 🏥");
  }

  function adicionarEntrada() {
    const entry = {
      ...novaEntrada,
      id: Date.now(),
      data: new Date().toISOString().slice(0, 10),
      semana: state.semanaManual,
    };
    save({ entradas: [entry, ...state.entradas] });
    setNovaEntrada({ humor: 3, sintomas: [], texto: "", peso: "", barriga: "" });
    setShowEntradaForm(false);
    showToast("Registro salvo! 💕");
  }

  function toggleSintoma(s) {
    setNovaEntrada(e => ({
      ...e,
      sintomas: e.sintomas.includes(s) ? e.sintomas.filter(x => x !== s) : [...e.sintomas, s]
    }));
  }

  const semana = state.semanaManual || 20;
  const dev = DESENVOLVIMENTO[semana] || DESENVOLVIMENTO[20];
  const proximasConsultas = state.consultas.filter(c => c.data >= new Date().toISOString().slice(0, 10));
  const consultasPassadas = state.consultas.filter(c => c.data < new Date().toISOString().slice(0, 10));
  const progresso = Math.round((semana / 40) * 100);
  const trimestre = semana <= 12 ? 1 : semana <= 27 ? 2 : 3;

  return (
    <div style={{ minHeight: "100vh", background: "#FFF5F7", fontFamily: "'Inter','Segoe UI',sans-serif", paddingBottom: 80 }}>

      {/* Toast */}
      {state.toast && (
        <div style={{
          position: "fixed", top: 20, left: "50%", transform: "translateX(-50%)",
          zIndex: 9999, background: state.toast.type === "error" ? "#FEE2E2" : "#FCE7F3",
          color: state.toast.type === "error" ? "#991B1B" : "#9D174D",
          borderRadius: 20, padding: "10px 22px", fontWeight: 700, fontSize: 13,
          boxShadow: "0 4px 20px rgba(0,0,0,0.12)", whiteSpace: "nowrap",
        }}>
          {state.toast.msg}
        </div>
      )}

      {/* Header */}
      <div style={{ background: "linear-gradient(135deg, #FDA4AF 0%, #F9A8D4 50%, #C4B5FD 100%)", padding: "24px 20px 16px", color: "#fff" }}>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start" }}>
          <div>
            <div style={{ fontSize: 11, fontWeight: 700, letterSpacing: 2, opacity: 0.8, textTransform: "uppercase" }}>
              {state.nomeMae || "Mamãe"} & {state.nomePai || "Papai"}
            </div>
            <h1 style={{ margin: "4px 0 2px", fontSize: 22, fontWeight: 800, letterSpacing: -0.5 }}>
              {state.nomeBebe ? `Bebê ${state.nomeBebe}` : "Nosso Bebê"} 👶
            </h1>
            <div style={{ fontSize: 13, opacity: 0.9 }}>
              Semana {semana} · {trimestre}º Trimestre
            </div>
          </div>
          <button onClick={() => setShowConfig(true)} style={{
            background: "rgba(255,255,255,0.25)", border: "none", borderRadius: 10,
            color: "#fff", padding: "8px 12px", cursor: "pointer", fontSize: 18,
          }}>⚙️</button>
        </div>

        {/* Barra de progresso */}
        <div style={{ marginTop: 16 }}>
          <div style={{ display: "flex", justifyContent: "space-between", fontSize: 11, opacity: 0.85, marginBottom: 5 }}>
            <span>Semana 1</span>
            <span style={{ fontWeight: 700 }}>{progresso}% concluído</span>
            <span>Semana 40</span>
          </div>
          <div style={{ height: 8, background: "rgba(255,255,255,0.3)", borderRadius: 10 }}>
            <div style={{ height: "100%", width: `${progresso}%`, background: "#fff", borderRadius: 10, transition: "width 0.5s" }} />
          </div>
          <div style={{ textAlign: "center", marginTop: 6, fontSize: 12, opacity: 0.85 }}>
            {40 - semana} semanas restantes
          </div>
        </div>
      </div>

      {/* Conteúdo */}
      <div style={{ maxWidth: 600, margin: "0 auto", padding: "20px 16px" }}>

        {/* INÍCIO */}
        {aba === "inicio" && (
          <div>
            {/* Card bebê da semana */}
            <div style={{ background: "#fff", borderRadius: 18, padding: 20, marginBottom: 14, boxShadow: "0 2px 12px rgba(253,164,175,0.15)", border: "1.5px solid #FDE8EF" }}>
              <div style={{ display: "flex", gap: 16, alignItems: "center" }}>
                <div style={{ fontSize: 52 }}>{dev.emoji}</div>
                <div style={{ flex: 1 }}>
                  <div style={{ fontSize: 11, fontWeight: 700, color: "#F472B6", textTransform: "uppercase", letterSpacing: 1 }}>Semana {semana} — Tamanho de um</div>
                  <div style={{ fontSize: 20, fontWeight: 800, color: "#1E293B" }}>{dev.tamanho}</div>
                  <div style={{ fontSize: 12, color: "#64748B", marginTop: 2 }}>{dev.cm} · {dev.peso}</div>
                </div>
              </div>
              <p style={{ margin: "12px 0 0", fontSize: 13, color: "#475569", lineHeight: 1.6 }}>{dev.desc}</p>
            </div>

            {/* Próximas consultas */}
            <div style={{ background: "#fff", borderRadius: 18, padding: 20, marginBottom: 14, border: "1.5px solid #E0E7FF" }}>
              <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 14 }}>
                <div style={{ fontWeight: 800, fontSize: 15, color: "#1E293B" }}>🏥 Próximas Consultas</div>
                <button onClick={() => { setAba("consultas"); setShowConsultaForm(true); }} style={{ background: "#EEF2FF", color: "#6366F1", border: "none", borderRadius: 8, padding: "5px 12px", fontWeight: 700, fontSize: 12, cursor: "pointer" }}>+ Adicionar</button>
              </div>
              {proximasConsultas.length === 0 ? (
                <div style={{ color: "#94A3B8", fontSize: 13, textAlign: "center", padding: "10px 0" }}>Nenhuma consulta agendada</div>
              ) : proximasConsultas.slice(0, 3).map(c => (
                <div key={c.id} style={{ display: "flex", gap: 12, alignItems: "center", padding: "10px 0", borderBottom: "1px solid #F1F5F9" }}>
                  <div style={{ background: "#EEF2FF", borderRadius: 10, padding: "8px 10px", textAlign: "center", minWidth: 46 }}>
                    <div style={{ fontSize: 16, fontWeight: 800, color: "#6366F1" }}>{c.data.split("-")[2]}</div>
                    <div style={{ fontSize: 9, color: "#818CF8", fontWeight: 700 }}>
                      {["","JAN","FEV","MAR","ABR","MAI","JUN","JUL","AGO","SET","OUT","NOV","DEZ"][parseInt(c.data.split("-")[1])]}
                    </div>
                  </div>
                  <div style={{ flex: 1 }}>
                    <div style={{ fontWeight: 700, fontSize: 13, color: "#1E293B" }}>{c.tipo}</div>
                    {c.medico && <div style={{ fontSize: 11, color: "#64748B" }}>Dr(a). {c.medico}</div>}
                    {c.local && <div style={{ fontSize: 11, color: "#94A3B8" }}>📍 {c.local}</div>}
                  </div>
                </div>
              ))}
            </div>

            {/* Último registro */}
            {state.entradas[0] && (
              <div style={{ background: "#fff", borderRadius: 18, padding: 20, border: "1.5px solid #FDE8EF" }}>
                <div style={{ fontWeight: 800, fontSize: 15, color: "#1E293B", marginBottom: 12 }}>📔 Último Registro</div>
                <div style={{ display: "flex", gap: 10, alignItems: "center", marginBottom: 8 }}>
                  <span style={{ fontSize: 28 }}>{HUMOR_CONFIG.find(h => h.valor === state.entradas[0].humor)?.emoji}</span>
                  <div>
                    <div style={{ fontWeight: 700, fontSize: 13, color: "#1E293B" }}>{HUMOR_CONFIG.find(h => h.valor === state.entradas[0].humor)?.label}</div>
                    <div style={{ fontSize: 11, color: "#94A3B8" }}>Semana {state.entradas[0].semana} · {formatData(state.entradas[0].data)}</div>
                  </div>
                </div>
                {state.entradas[0].sintomas?.length > 0 && (
                  <div style={{ display: "flex", gap: 6, flexWrap: "wrap" }}>
                    {state.entradas[0].sintomas.slice(0, 4).map(s => (
                      <span key={s} style={{ background: "#FDF2F8", color: "#DB2777", fontSize: 11, fontWeight: 600, borderRadius: 20, padding: "2px 10px" }}>{s}</span>
                    ))}
                  </div>
                )}
                {state.entradas[0].texto && <p style={{ margin: "10px 0 0", fontSize: 13, color: "#475569", lineHeight: 1.5 }}>{state.entradas[0].texto}</p>}
              </div>
            )}

            <button onClick={() => setShowEntradaForm(true)} style={{
              width: "100%", marginTop: 14, padding: "15px 0",
              background: "linear-gradient(135deg, #FDA4AF, #F9A8D4)",
              color: "#fff", border: "none", borderRadius: 14,
              fontWeight: 800, fontSize: 15, cursor: "pointer",
              boxShadow: "0 4px 14px rgba(253,164,175,0.4)",
            }}>
              💕 Registrar Como Estou Hoje
            </button>
          </div>
        )}

        {/* DESENVOLVIMENTO */}
        {aba === "desenvolvimento" && (
          <div>
            <div style={{ fontWeight: 800, fontSize: 17, color: "#1E293B", marginBottom: 16 }}>👶 Desenvolvimento Semana a Semana</div>
            {Object.entries(DESENVOLVIMENTO).map(([sem, d]) => {
              const s = parseInt(sem);
              const atual = s === semana;
              const passada = s < semana;
              return (
                <div key={sem} style={{
                  background: atual ? "linear-gradient(135deg, #FDF2F8, #EDE9FE)" : "#fff",
                  borderRadius: 14, padding: "16px", marginBottom: 10,
                  border: atual ? "2px solid #F9A8D4" : "1.5px solid #F1F5F9",
                  opacity: passada ? 0.7 : 1,
                }}>
                  <div style={{ display: "flex", gap: 12, alignItems: "center" }}>
                    <div style={{ fontSize: 36 }}>{d.emoji}</div>
                    <div style={{ flex: 1 }}>
                      <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
                        <span style={{ fontWeight: 800, fontSize: 14, color: "#1E293B" }}>Semana {sem} — {d.tamanho}</span>
                        {atual && <span style={{ background: "#F9A8D4", color: "#9D174D", fontSize: 10, fontWeight: 800, borderRadius: 20, padding: "2px 8px" }}>AGORA</span>}
                        {passada && <span style={{ fontSize: 14 }}>✅</span>}
                      </div>
                      <div style={{ fontSize: 11, color: "#94A3B8", marginTop: 1 }}>{d.cm} · {d.peso}</div>
                      <p style={{ margin: "6px 0 0", fontSize: 12, color: "#475569", lineHeight: 1.5 }}>{d.desc}</p>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        )}

        {/* CONSULTAS */}
        {aba === "consultas" && (
          <div>
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 16 }}>
              <div style={{ fontWeight: 800, fontSize: 17, color: "#1E293B" }}>🏥 Consultas e Exames</div>
              <button onClick={() => setShowConsultaForm(true)} style={{ background: "#EEF2FF", color: "#6366F1", border: "none", borderRadius: 9, padding: "8px 16px", fontWeight: 700, fontSize: 13, cursor: "pointer" }}>+ Nova</button>
            </div>

            {proximasConsultas.length > 0 && (
              <>
                <div style={{ fontSize: 11, fontWeight: 700, color: "#6366F1", textTransform: "uppercase", letterSpacing: 1, marginBottom: 8 }}>Próximas</div>
                {proximasConsultas.map(c => <ConsultaCard key={c.id} c={c} />)}
              </>
            )}

            {consultasPassadas.length > 0 && (
              <>
                <div style={{ fontSize: 11, fontWeight: 700, color: "#94A3B8", textTransform: "uppercase", letterSpacing: 1, margin: "16px 0 8px" }}>Realizadas</div>
                {consultasPassadas.map(c => <ConsultaCard key={c.id} c={c} passada />)}
              </>
            )}

            {state.consultas.length === 0 && (
              <div style={{ textAlign: "center", padding: "40px 0", color: "#94A3B8" }}>
                <div style={{ fontSize: 40, marginBottom: 10 }}>🏥</div>
                <div style={{ fontWeight: 600 }}>Nenhuma consulta cadastrada</div>
                <div style={{ fontSize: 13, marginTop: 4 }}>Adicione sua primeira consulta!</div>
              </div>
            )}
          </div>
        )}

        {/* DIÁRIO */}
        {aba === "diario" && (
          <div>
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 16 }}>
              <div style={{ fontWeight: 800, fontSize: 17, color: "#1E293B" }}>📔 Diário da Mamãe</div>
              <button onClick={() => setShowEntradaForm(true)} style={{ background: "#FDF2F8", color: "#DB2777", border: "none", borderRadius: 9, padding: "8px 16px", fontWeight: 700, fontSize: 13, cursor: "pointer" }}>+ Registrar</button>
            </div>

            {state.entradas.length === 0 ? (
              <div style={{ textAlign: "center", padding: "40px 0", color: "#94A3B8" }}>
                <div style={{ fontSize: 40, marginBottom: 10 }}>📔</div>
                <div style={{ fontWeight: 600 }}>Nenhum registro ainda</div>
                <div style={{ fontSize: 13, marginTop: 4 }}>Comece a registrar como você está!</div>
              </div>
            ) : state.entradas.map(e => {
              const hConf = HUMOR_CONFIG.find(h => h.valor === e.humor);
              return (
                <div key={e.id} style={{ background: "#fff", borderRadius: 16, padding: "16px", marginBottom: 10, border: "1.5px solid #FDE8EF" }}>
                  <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 10 }}>
                    <div style={{ display: "flex", gap: 10, alignItems: "center" }}>
                      <span style={{ fontSize: 28 }}>{hConf?.emoji}</span>
                      <div>
                        <div style={{ fontWeight: 700, fontSize: 14, color: "#1E293B" }}>{hConf?.label}</div>
                        <div style={{ fontSize: 11, color: "#94A3B8" }}>Semana {e.semana} · {formatData(e.data)}</div>
                      </div>
                    </div>
                    <div style={{ display: "flex", gap: 8 }}>
                      {e.peso && <span style={{ fontSize: 11, background: "#F0FDF4", color: "#16A34A", fontWeight: 700, borderRadius: 20, padding: "2px 8px" }}>⚖️ {e.peso}kg</span>}
                      {e.barriga && <span style={{ fontSize: 11, background: "#EFF6FF", color: "#2563EB", fontWeight: 700, borderRadius: 20, padding: "2px 8px" }}>📏 {e.barriga}cm</span>}
                    </div>
                  </div>
                  {e.sintomas?.length > 0 && (
                    <div style={{ display: "flex", gap: 5, flexWrap: "wrap", marginBottom: 8 }}>
                      {e.sintomas.map(s => (
                        <span key={s} style={{ background: "#FDF2F8", color: "#DB2777", fontSize: 11, fontWeight: 600, borderRadius: 20, padding: "2px 9px" }}>{s}</span>
                      ))}
                    </div>
                  )}
                  {e.texto && <p style={{ margin: 0, fontSize: 13, color: "#475569", lineHeight: 1.6, fontStyle: "italic" }}>"{e.texto}"</p>}
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* Bottom Nav */}
      <div style={{
        position: "fixed", bottom: 0, left: 0, right: 0,
        background: "#fff", borderTop: "1px solid #F1F5F9",
        display: "flex", padding: "8px 0 12px",
        boxShadow: "0 -4px 20px rgba(0,0,0,0.08)",
      }}>
        {ABAS.map(a => (
          <button key={a.key} onClick={() => setAba(a.key)} style={{
            flex: 1, display: "flex", flexDirection: "column", alignItems: "center",
            gap: 3, background: "none", border: "none", cursor: "pointer",
            color: aba === a.key ? "#F472B6" : "#94A3B8",
            fontWeight: aba === a.key ? 700 : 500, fontSize: 10,
          }}>
            <span style={{ fontSize: 22 }}>{a.label.split(" ")[0]}</span>
            <span>{a.label.split(" ").slice(1).join(" ")}</span>
          </button>
        ))}
      </div>

      {/* Modal: Nova Consulta */}
      {showConsultaForm && (
        <Modal title="Nova Consulta / Exame" onClose={() => setShowConsultaForm(false)}>
          <label style={lbl}>Tipo *</label>
          <input value={novaConsulta.tipo} onChange={e => setNovaConsulta(n => ({ ...n, tipo: e.target.value }))}
            placeholder="Ex: Pré-natal, Ultrassom, Exame de sangue..." style={inp} />
          <label style={lbl}>Data *</label>
          <input type="date" value={novaConsulta.data} onChange={e => setNovaConsulta(n => ({ ...n, data: e.target.value }))} style={inp} />
          <label style={lbl}>Médico(a)</label>
          <input value={novaConsulta.medico} onChange={e => setNovaConsulta(n => ({ ...n, medico: e.target.value }))}
            placeholder="Nome do médico" style={inp} />
          <label style={lbl}>Local / Clínica</label>
          <input value={novaConsulta.local} onChange={e => setNovaConsulta(n => ({ ...n, local: e.target.value }))}
            placeholder="Nome da clínica ou hospital" style={inp} />
          <label style={lbl}>Observações</label>
          <textarea value={novaConsulta.obs} onChange={e => setNovaConsulta(n => ({ ...n, obs: e.target.value }))}
            placeholder="Anotações, resultados, dúvidas..." rows={2} style={{ ...inp, resize: "vertical" }} />
          <div style={{ display: "flex", gap: 10, marginTop: 8 }}>
            <button onClick={() => setShowConsultaForm(false)} style={btnSec}>Cancelar</button>
            <button onClick={adicionarConsulta} style={btnPri}>Salvar</button>
          </div>
        </Modal>
      )}

      {/* Modal: Novo Registro Diário */}
      {showEntradaForm && (
        <Modal title="Como você está hoje? 💕" onClose={() => setShowEntradaForm(false)}>
          <label style={lbl}>Humor da mamãe</label>
          <div style={{ display: "flex", gap: 8, marginBottom: 16, justifyContent: "center" }}>
            {HUMOR_CONFIG.map(h => (
              <button key={h.valor} onClick={() => setNovaEntrada(e => ({ ...e, humor: h.valor }))} style={{
                fontSize: 28, background: novaEntrada.humor === h.valor ? "#FDF2F8" : "transparent",
                border: novaEntrada.humor === h.valor ? "2px solid #F9A8D4" : "2px solid transparent",
                borderRadius: 12, padding: "6px 10px", cursor: "pointer",
              }}>{h.emoji}</button>
            ))}
          </div>

          <label style={lbl}>Sintomas / Como está se sentindo</label>
          <div style={{ display: "flex", gap: 6, flexWrap: "wrap", marginBottom: 14 }}>
            {SINTOMAS_OPCOES.map(s => (
              <button key={s} onClick={() => toggleSintoma(s)} style={{
                fontSize: 12, fontWeight: 600, borderRadius: 20, padding: "4px 10px", cursor: "pointer",
                background: novaEntrada.sintomas.includes(s) ? "#FDF2F8" : "#F8FAFC",
                color: novaEntrada.sintomas.includes(s) ? "#DB2777" : "#64748B",
                border: novaEntrada.sintomas.includes(s) ? "1.5px solid #F9A8D4" : "1.5px solid #E2E8F0",
              }}>{s}</button>
            ))}
          </div>

          <div style={{ display: "flex", gap: 10 }}>
            <div style={{ flex: 1 }}>
              <label style={lbl}>Peso (kg)</label>
              <input type="number" step="0.1" value={novaEntrada.peso} onChange={e => setNovaEntrada(n => ({ ...n, peso: e.target.value }))}
                placeholder="Ex: 65.5" style={inp} />
            </div>
            <div style={{ flex: 1 }}>
              <label style={lbl}>Barriga (cm)</label>
              <input type="number" value={novaEntrada.barriga} onChange={e => setNovaEntrada(n => ({ ...n, barriga: e.target.value }))}
                placeholder="Ex: 28" style={inp} />
            </div>
          </div>

          <label style={lbl}>Anotação livre</label>
          <textarea value={novaEntrada.texto} onChange={e => setNovaEntrada(n => ({ ...n, texto: e.target.value }))}
            placeholder="Como foi seu dia? Sentiu o bebê se mexer? Alguma memória especial..." rows={3}
            style={{ ...inp, resize: "vertical" }} />
          <div style={{ display: "flex", gap: 10, marginTop: 8 }}>
            <button onClick={() => setShowEntradaForm(false)} style={btnSec}>Cancelar</button>
            <button onClick={adicionarEntrada} style={btnPri}>Salvar 💕</button>
          </div>
        </Modal>
      )}

      {/* Modal: Configurações */}
      {showConfig && (
        <Modal title="⚙️ Configurações" onClose={() => setShowConfig(false)}>
          <label style={lbl}>Nome do bebê (ou apelido)</label>
          <input value={config.nomeBebe} onChange={e => setConfig(c => ({ ...c, nomeBebe: e.target.value }))}
            placeholder="Ex: Princesinha, Bento, Ainda não sei..." style={inp} />
          <label style={lbl}>Nome da mamãe</label>
          <input value={config.nomeMae} onChange={e => setConfig(c => ({ ...c, nomeMae: e.target.value }))}
            placeholder="Mamãe" style={inp} />
          <label style={lbl}>Nome do papai</label>
          <input value={config.nomePai} onChange={e => setConfig(c => ({ ...c, nomePai: e.target.value }))}
            placeholder="Papai" style={inp} />
          <label style={lbl}>Semana atual da gestação</label>
          <div style={{ display: "flex", alignItems: "center", gap: 12, marginBottom: 14 }}>
            <input type="range" min={1} max={40} value={config.semana}
              onChange={e => setConfig(c => ({ ...c, semana: parseInt(e.target.value) }))}
              style={{ flex: 1, accentColor: "#F472B6" }} />
            <span style={{ fontWeight: 800, fontSize: 18, color: "#F472B6", minWidth: 30 }}>{config.semana}</span>
          </div>
          <button onClick={salvarConfig} style={{ ...btnPri, width: "100%" }}>Salvar 💕</button>
        </Modal>
      )}
    </div>
  );
}

function ConsultaCard({ c, passada }) {
  const meses = ["","JAN","FEV","MAR","ABR","MAI","JUN","JUL","AGO","SET","OUT","NOV","DEZ"];
  const [y, m, d] = c.data.split("-");
  return (
    <div style={{
      background: passada ? "#F8FAFC" : "#fff", borderRadius: 14, padding: "14px 16px",
      marginBottom: 8, border: `1.5px solid ${passada ? "#E2E8F0" : "#E0E7FF"}`,
      display: "flex", gap: 14, alignItems: "flex-start",
      opacity: passada ? 0.7 : 1,
    }}>
      <div style={{ background: passada ? "#F1F5F9" : "#EEF2FF", borderRadius: 10, padding: "8px 10px", textAlign: "center", minWidth: 46 }}>
        <div style={{ fontSize: 18, fontWeight: 800, color: passada ? "#94A3B8" : "#6366F1" }}>{d}</div>
        <div style={{ fontSize: 9, color: passada ? "#94A3B8" : "#818CF8", fontWeight: 700 }}>{meses[parseInt(m)]}</div>
      </div>
      <div style={{ flex: 1 }}>
        <div style={{ fontWeight: 700, fontSize: 14, color: "#1E293B" }}>{c.tipo} {passada ? "✅" : ""}</div>
        {c.medico && <div style={{ fontSize: 12, color: "#64748B", marginTop: 2 }}>👩‍⚕️ Dr(a). {c.medico}</div>}
        {c.local && <div style={{ fontSize: 12, color: "#94A3B8" }}>📍 {c.local}</div>}
        {c.obs && <div style={{ fontSize: 12, color: "#64748B", marginTop: 4, fontStyle: "italic" }}>{c.obs}</div>}
      </div>
    </div>
  );
}

function Modal({ title, children, onClose }) {
  return (
    <div style={{ position: "fixed", inset: 0, background: "rgba(15,23,42,0.5)", zIndex: 1000, display: "flex", alignItems: "flex-end", justifyContent: "center", padding: "0" }}>
      <div style={{ background: "#fff", borderRadius: "20px 20px 0 0", padding: "24px 20px 32px", width: "100%", maxWidth: 600, maxHeight: "90vh", overflowY: "auto", boxShadow: "0 -8px 40px rgba(0,0,0,0.15)" }}>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 20 }}>
          <h2 style={{ margin: 0, fontSize: 17, fontWeight: 800, color: "#1E293B" }}>{title}</h2>
          <button onClick={onClose} style={{ background: "none", border: "none", fontSize: 20, cursor: "pointer", color: "#94A3B8" }}>✕</button>
        </div>
        {children}
      </div>
    </div>
  );
}

const lbl = {
  display: "block", fontSize: 11, fontWeight: 700, color: "#475569",
  textTransform: "uppercase", letterSpacing: 0.8, marginBottom: 5,
};

const inp = {
  width: "100%", padding: "10px 13px", border: "1.5px solid #E2E8F0",
  borderRadius: 9, fontSize: 14, outline: "none", background: "#F8FAFC",
  color: "#1E293B", boxSizing: "border-box", marginBottom: 14, fontFamily: "inherit",
};

const btnPri = {
  flex: 1, padding: "12px 0", borderRadius: 10, border: "none",
  background: "linear-gradient(135deg, #FDA4AF, #F9A8D4)",
  color: "#fff", fontWeight: 700, fontSize: 14, cursor: "pointer",
};

const btnSec = {
  flex: 1, padding: "12px 0", borderRadius: 10,
  border: "1.5px solid #E2E8F0", background: "#F8FAFC",
  color: "#64748B", fontWeight: 700, fontSize: 14, cursor: "pointer",
};
